<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Transfer extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "transfer";
    var $sub_menu_name = "transfer";
    var $title = "Transfer Items";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('purchases_model');
        $this->load->model('category_model');
        $this->load->model('supplier_model');
        $this->load->model('warehouse_model');
        $this->load->model('payments_model');
        $this->load->model('transfer_model');
    }
    function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_transfer';
        $data['title']          = $this->title;
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $this->load->view('transfer/transfer-list', $data);
    }
    function add()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'add_transfer';
        $data['title']          = 'Add '.$this->title;
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $this->load->view('transfer/transfer-add', $data);
    }
    function save_transfer()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('trnsfr_from_warehouse_id', 'From warehouse', 'required');
        $this->form_validation->set_rules('trnsfr_to_warehouse_id', 'To warehouse', 'required');
        $this->form_validation->set_rules('trnsfr_datetime', 'Time stamp', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'status' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $products            = $this->input->post('row');
            if (!count($products) > 0) {
                $st = array(
                    'status' => false,
                    'validation' => "No products received!"
                );
                echo json_encode($st);
                exit;
            }
            $warehouse_id        = $this->session->userdata('ss_warehouse_id');
            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id);
            $trnsfr_from_warehouse_id        = $this->input->post('trnsfr_from_warehouse_id');
            $trnsfr_to_warehouse_id         = $this->input->post('trnsfr_to_warehouse_id');
            
            $trnsfr_total = 0;
            $item_batch = array();
            foreach ($products as $row) {
                $sub_total =  $row['quantity'] * $row['product_cost'];
                $item_data        = array(
                    'product_id' => $row['product_id'],
                    'trnsfr_itm_quantity' => $row['quantity'],
                    'trnsfr_itm_unit_price' => $row['product_cost'],
                    'trnsfr_itm_sub_total' => $sub_total,
                    'warehouse_from_id' => $trnsfr_from_warehouse_id,
                    'warehouse_to_id' => $trnsfr_to_warehouse_id
                );
                $trnsfr_total += $sub_total;
                $item_batch[] = $item_data;
            }

            $reference_no           = $this->common_model->gen_ref_number('trnsfr_id', 'transfer', 'TSF');

            $trnsfr_datetime     = $this->input->post('trnsfr_datetime');
            $trnsfr_note                = $this->input->post('trnsfr_note');
            $user_id             = $this->session->userdata('ss_user_id');
            $uuid                = $this->input->post('uuid');

            $pur_data        = array(
                'trnsfr_reference_no' => $warehouse_info->code .$reference_no,
                'trnsfr_datetime' => $trnsfr_datetime,
                'trnsfr_from_warehouse_id' => $trnsfr_from_warehouse_id,
                'trnsfr_to_warehouse_id' => $trnsfr_to_warehouse_id,
                'trnsfr_note' => $trnsfr_note,
                'trnsfr_total' => $trnsfr_total,
                'user_id' => $user_id,
                'uuid' => $uuid,
                'warehouse_id'=> $warehouse_id
            );
            $last_id             = $this->common_model->save($pur_data, 'transfer');
            if ($last_id) {
                foreach ($item_batch as $key => $row) {
                    $item_batch[$key]['trnsfr_id'] = $last_id;
                }
                $item_lst_id             = $this->common_model->save_batch($item_batch, 'transfer_item');
                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'validation' => 'Done!',
                        'value' => array(
                            'last_id' => $last_id
                        )
                    );
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'validation' => 'Error occurred. please contact your system administrator.'
                    );
                    echo json_encode($st);
                }
            } else {
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
    function get_list(){
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        $filter = array(
            "search_key"=>$search_key['value'],
            "trnsfr_datetime"=>$this->input->post('trnsfr_datetime'),
            "trnsfr_from_warehouse_id"=>$this->input->post('trnsfr_from_warehouse_id'),
            "trnsfr_to_warehouse_id"=>$this->input->post('trnsfr_to_warehouse_id'),
            "warehouse_id"=>($this->input->post('warehouse_id'))?$this->input->post('warehouse_id'):$this->session->userdata('ss_warehouse_id')
        );
        $values        = $this->transfer_model->get_transfers($start, $length, $filter);
        $value_count   = $this->transfer_model->get_transfers('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $nestedData[]   = $row->trnsfr_datetime;
                $nestedData[]   = $row->trnsfr_reference_no ;
                $nestedData[]   = $row->trnsfr_from_warehouse_id;
                $nestedData[]   = $row->trnsfr_to_warehouse_id;
                $nestedData[]   = $row->trnsfr_total;
                $nestedData[]   = $row->trnsfr_note;
                $nestedData[]   = '';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
}
