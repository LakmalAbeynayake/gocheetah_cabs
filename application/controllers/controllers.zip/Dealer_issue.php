<?php
defined('BASEPATH') or exit('No direct script access allowed');
class dealer_issue extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "dealer_issue";
    var $sub_menu_name = "add_dealer_issues";
    var $title = "Dealer Issues";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('dealer_issue_model');
        $this->load->model('category_model');
        $this->load->model('supplier_model');
        $this->load->model('warehouse_model');
        $this->load->model('payments_model');
    }
    public function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'dealer_issues_list';
        $data['title']          = $this->title;
        $data['warehouse']      = $this->warehouse_model->get_warehouses();
        $this->load->view('dealer_issues/dealer_issues-list', $data);
    }
    public function add()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'dealer_issues_add';
        $data['title']          = $this->title;
        $data['supplier']       = array();
        $data['main_category']  = $this->category_model->get_categories();
        $data['warehouse']      = $this->warehouse_model->get_warehouses();
        $this->load->view('dealer_issues/dealer_issues-add', $data);
    }
    public function view()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        //$id = $this->uri->segment(3);
        $id = $this->input->get('dealer_issue_id');

        $data['dealer_issue_info'] = $this->dealer_issue_model->get_dealer_issue($id);
        $data['dealer_issue_item'] = $this->dealer_issue_model->get_dealer_issue_items($id);

        $this->load->view('dealer_issues/dealer_issues-info', $data);
    }
    public function view_batch()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        $id = $this->input->get('prdb_id');
        $data['dealer_issue_data'] = $this->dealer_issue_model->get_dealer_issue_batch_info($id);
        //print_r($data['dealer_issue_data']);
        $data['dealer_issue_items_data']  =   $this->dealer_issue_model->get_dealer_issue_items_info_by_batch_id($id);
        //print_r($data['dealer_issue_items_data']);
        $this->load->view('dealer_issues/dealer_issues-info-batch', $data);
    }
    public function create_dealer_issue_batch()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('warehouse_id', 'Product Name', 'required');
        $this->form_validation->set_rules('dealer_issue_date_time', 'Date', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'success' => false,
                'msg' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $dealer_issue_date_time  = $this->input->post('dealer_issue_date_time');
            $note                = $this->input->post('note');
            $warehouse_id        = $this->input->post('warehouse_id');
            $uuid                = $this->input->post('uuid');
            $user_id             = $this->session->userdata('ss_user_id');
            $dealer_issue_total = 0;

            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'));
            $reference_no        = $this->common_model->gen_ref_number_v1('reference_no', 'dealer_issues', $warehouse_info->code . '/PRD' . date('ym') . '/', array(
                'warehouse_id' => $warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'),
                'date(date_time) >=' => date('Y-m-01')
            ));


            $pur_data        = array(
                'reference_no' => $reference_no,
                'warehouse_id' => $warehouse_id,
                'dealer_issue_date_time' => $dealer_issue_date_time,
                'note' => $note,
                'dealer_issue_total' => $dealer_issue_total,
                'user_id' => $user_id,
                'uuid' => $uuid,
            );
            $this->db->trans_begin();
            $this->db->trans_strict();
            $last_id             = $this->common_model->save($pur_data, 'dealer_issues');
            if ($last_id) {
                $st = array(
                    'success' => true,
                    'msg' => 'Batch created successfully!',
                    'url' => 'dealer_issue/set_raw_mats?dealer_issue_id=' . $last_id,
                    'values' => array(
                        'last_id' => $last_id
                    )
                );
                $this->db->trans_commit();
                echo json_encode($st);
            } else {
                $st = array(
                    'success' => false,
                    'msg' => 'Error occurred. please contact your system administrator. -H2'
                );
                $this->db->trans_rollback();
                echo json_encode($st);
            }
        }
    }
    public function save_dealer_issue()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('dealer_issue_id', 'Production ID', 'required');
        $this->form_validation->set_rules('product_id', 'Product ID', 'required');
        $this->form_validation->set_rules('batch_no', 'Batch No', 'required');
        $this->form_validation->set_rules('dealer_issue_qty', 'Manufacturing Quantity', 'required');
        $this->form_validation->set_rules('warehouse_id', 'Warehouse ID', 'required');
        $this->form_validation->set_rules('expire_date', 'Expiry ID', 'required');
        $this->form_validation->set_rules('mrp', 'MRP', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'success' => false,
                'msg' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $raw_mats            = $this->input->post('row');
            /* echo "<pre>";
            print_r($raw_mats);
            echo "</pre>";
            exit; */
            if (!count($raw_mats) > 0) {
                $st = array(
                    'success' => false,
                    'msg' => "No Row-materials data received!"
                );
                echo json_encode($st);
                exit;
            }
            $batch_no       = $this->input->post('batch_no');
            $product_id     = $this->input->post('product_id');
            $dealer_issue_qty = $this->input->post('dealer_issue_qty');
            $dealer_issue_id  = $this->input->post('dealer_issue_id');
            $warehouse_id   = $this->input->post('warehouse_id');
            $expire_date    = $this->input->post('expire_date');
            $uuid           = $this->input->post('uuid');
            $mrp            = $this->input->post('mrp');
            $user_id        = $this->session->userdata('ss_user_id');

            $cost_total = 0;
            $dealer_issue_raw_materials = array();
            foreach ($raw_mats as $row) {
                $item_data        = array(
                    'product_id' => $product_id,
                    'raw_mat_id' => $row['raw_mat_id'],
                    'raw_mat_qty' => $row['required_qty'],
                    'batch_id' => $row['batch_id'], //purchase_batch_id
                    'batch_type' => $row['batch_type'], //purchase_batch_id
                    'purchase_batch_cost' => $row['batch_cost'],
                    'sub_total_cost' => $row['required_qty'] * $row['batch_cost'],
                    'warehouse_id' => $warehouse_id
                );
                $cost_total += ($row['required_qty'] * $row['batch_cost']);
                $dealer_issue_raw_materials[] = $item_data;
            }
            /* Batch Validation */
            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'));
            $reference_no        = $this->common_model->gen_ref_number_v1('prdb_ref_no', 'dealer_issue_batch', $warehouse_info->code . 'PRB/' . date('ym') . '/', array(
                'warehouse_id' => $warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'),
                'date(date_time) >=' => date('Y-m-01')
            ));
            $dealer_issue_batch_data = array(
                'product_id' => $product_id,
                'prdb_ref_no' => $reference_no,
                'prdb_code' => $batch_no,
                'prdb_cost' => $cost_total,
                'prdb_mrp' => $mrp,
                'prdb_added_date_time' => date('Y-m-d H:i:s'),
                'expire_date' => $expire_date,
                'prdb_in_use' => 1,
                'prdb_added_by' => $this->session->userdata('ss_user_id'),
                'warehouse_id' => $warehouse_id,
                'date_time' => date("Y-m-d H:i:s"),
                'uuid' => $uuid
            );
            $is_pb_valid = $this->validate_dealer_issue_batch($dealer_issue_batch_data);
            if (!$is_pb_valid['success']) {
                $st = array(
                    'success' => false,
                    'msg' => "Invalid batch for cost!"
                );
                echo json_encode($st);
            }
            /* End batch validation */
            $main_product_data  = array(
                'dealer_issue_id' => $dealer_issue_id,
                'dealer_issue_batch_id' => $is_pb_valid['pb_id'],
                'product_id' => $product_id,
                'batch_no' => $batch_no,
                'product_cost' => $cost_total,
                'dealer_issue_quantity' => $dealer_issue_qty,
                'warehouse_id' => $warehouse_id,
                'uuid' => $uuid,
                'user_id' => $user_id
            );
            $this->db->trans_begin();
            $this->db->trans_strict();
            $dealer_issue_item_id             = $this->common_model->save($main_product_data, 'dealer_issue_items');
            if ($dealer_issue_item_id) {
                foreach ($dealer_issue_raw_materials as $key => $row) {
                    $dealer_issue_raw_materials[$key]['dealer_issue_item_id'] = $dealer_issue_item_id;
                }
                $item_lst_id             = $this->common_model->save_batch($dealer_issue_raw_materials, 'dealer_issue_raw_materials');
                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'msg' => 'Added Successfully',
                        'url' => 'dealer_issue/set_raw_mats?dealer_issue_id=' . $dealer_issue_id,
                        'values' => array(
                            'dealer_issue_id' => $dealer_issue_id
                        )
                    );
                    $this->db->trans_commit();
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'msg' => 'Error occurred. please contact your system administrator. -H1'
                    );
                    $this->db->trans_rollback();
                    echo json_encode($st);
                }
            } else {
                $st = array(
                    'success' => false,
                    'msg' => 'Error occurred. please contact your system administrator. -H2'
                );
                $this->db->trans_rollback();
                echo json_encode($st);
            }
        }
    }
    function price_filter($amount = '')
    {
        $s = array();
        $s = explode("Rs.", $amount);
        return str_replace(',', '', $s[1]);
    }
    function get_list()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        $filter = array(
            'search_key_value' => $search_key['value'],
            'warehouse_id' => ($this->input->post('warehouse_id')) ? $this->input->get('warehouse_id') : $this->session->userdata('ss_warehouse_id'),
        );

        /* $filter[2]     = $this->input->get('sub_cat_id');
        $filter[3]     = $this->input->get('brand_id'); */
        /* $filter = array(
        'search_key_val'=>     $search_key['value'],
        'cat_id'        =>     $this->input->get('cat_id'),
        'sub_cat_id'    =>    $this->input->get('sub_cat_id'),
        'brand_id'        =>    $this->input->get('brand_id')
        ); */
        $values        = $this->dealer_issue_model->get_dealer_issues($start, $length, $filter);
        $value_count   = $this->dealer_issue_model->get_dealer_issues('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $nestedData[]   = $row->reference_no;
                $nestedData[]   = date("Y-m-d H:i:s a", strtotime($row->dealer_issue_date_time));
                $nestedData[]   = $row->note ? $row->note : 'N/A';
                $nestedData[]   = $row->dealer_issue_status ? 'ENABLED' : 'DISABLED';
                $nestedData[]   = '<div style="display: flex;justify-content: space-evenly;">
                <a class="btn btn-sm btn-warning" href="' . base_url() . 'dealer_issue/set_raw_mats?dealer_issue_id=' . $row->dealer_issue_id . '">Add Products</a>
                <a class="btn btn-sm btn-success" href="' . base_url() . 'dealer_issue/view?dealer_issue_id=' . $row->dealer_issue_id . '"> View Production</a>
                </div>';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    /* ASSIGN RAW MATERIALS */
    function set_raw_mats()
    {
        $this->load->model('products_model');
        $dealer_issue_id = $this->input->get('dealer_issue_id');

        $data['product_id']     = $this->input->get('product_id');
        $data['dealer_issue_qty'] = $this->input->get('dealer_issue_qty');
        $data['product_name']   = $this->input->get('product_name');

        $data['dealer_issue_info'] = $this->dealer_issue_model->get_dealer_issue($dealer_issue_id);
        $data['dealer_issue_item'] = $this->dealer_issue_model->get_dealer_issue_items($dealer_issue_id);
        $data['main_menu_name'] = 'dealer_issue';
        $data['sub_menu_name']  = 'dealer_issue_add';
        $data['title']          = $this->title;
        if (empty($data['dealer_issue_info']))
            show_404();
        $this->load->view('dealer_issues/dealer_issues-set_raw_mats', $data);
    }
    function batch()
    {
        $data['main_menu_name'] = 'dealer_issue';
        $data['sub_menu_name']  = 'dealer_issue_batch';
        $data['title']          = 'Production Batches';
        $this->load->view('dealer_issues/dealer_issues-list_batch', $data);
    }
    function get_list_batch()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');

        //$filter[0]     = $search_key['value'];
        $filter['warehouse_id']     = ($this->input->post('warehouse_id')) ? $this->input->post('warehouse_id') : $this->session->userdata('ss_warehouse_id');

        /* $filter[2]     = $this->input->get('sub_cat_id');
        $filter[3]     = $this->input->get('brand_id'); */
        /* $filter = array(
            'search_key_val'    =>     $search_key['value'],
            'cat_id'            =>     $this->input->get('cat_id'),
            'sub_cat_id'        =>    $this->input->get('sub_cat_id'),
            'brand_id'          =>    $this->input->get('brand_id')
        ); */

        $values        = $this->dealer_issue_model->get_dealer_issue_batches($start, $length, $filter);
        $value_count   = $this->dealer_issue_model->get_dealer_issue_batches('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $buttons = '';
                $btn_enable = '<a href="#" onClick="enable(' . $row->prdb_id . ')" class="btn btn-sm btn-success"><i class="fa fa-check"></i> Enable</a>';
                $btn_disbale = '<a href="#" onClick="disable(' . $row->prdb_id . ')" class="btn btn-sm btn-warning"><i class="fa fa-minus-circle"></i> Disable</a>';
                $btn_view    = '<a href="' . base_url() . 'dealer_issue/view_batch?prdb_id=' . $row->prdb_id . '" class="btn btn-sm btn-info"><i class="fa fa-file"></i> Details</a>';

                $buttons .= $row->prdb_in_use ? $btn_disbale : $btn_enable;
                $buttons .= $btn_view;
                $mfq = $this->dealer_issue_model->get_manufactured_qty_by_prdb_id($row->prdb_id);
                $nestedData[]   = $row->prdb_code;
                $nestedData[]   = $row->product_name;
                $nestedData[]   = $row->prdb_added_date_time;
                $nestedData[]   = $row->expire_date;
                $nestedData[]   = $row->prdb_cost;
                $nestedData[]   = $mfq->dealer_issue_quantity;
                $nestedData[]   = $row->prdb_in_use ? "ENABLED" : "DSIABLED";
                $nestedData[]   = '<div style="display: flex;justify-content: space-evenly;">' . $buttons . '</div>';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    /* Open dealer_issue sheet*/
    function open()
    {
        $id = $this->input->get('id');
        $response = $this->dealer_issue_model->open($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Opened Successfully" : "Error"
        ));
    }
    /* Close dealer_issue sheet*/
    function close()
    {
        $id = $this->input->get('id');
        $response = $this->dealer_issue_model->close($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Closed Successfully" : "Error"
        ));
    }
    /* enable dealer_issue batch*/
    function enable()
    {
        $id = $this->input->get('id');
        $response = $this->dealer_issue_model->enable($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Enabled Successfully" : "Error"
        ));
    }
    /* disable dealer_issue batch*/
    function disable()
    {
        $id = $this->input->get('id');
        $response = $this->dealer_issue_model->disable($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Disabled Successfully" : "Error"
        ));
    }
    function validate_dealer_issue_batch($pb_data)
    {
        //print_r($pb_data);exit;
        $pro_batch_id = 0;
        $pb_info = $this->dealer_issue_model->get_dealer_issue_batch_info_by_batch_no($pb_data['prdb_code'], $pb_data['prdb_cost'], $pb_data['warehouse_id']);
        //ANYTHING???
        if (!empty($pb_info)) {
            // YES. That means, there IS a batch so lets check if it's the same product that we're trying to allocate
            if ($pb_info->product_id == $pb_data['product_id']) {
                //oo yeah its same. good to go. lets return those numbers so their job will be easy
                return array(
                    'success' => true,
                    'msg' => 'Good to go',
                    'pb_id' => $pb_info->prdb_id
                );
            } else {
                //oho no its not. Back off dude!!!!
                return array(
                    'success' => false,
                    'msg' => 'This batch no is already assigned for another product!'
                );
            }
        } else {
            //NO. That means, we have to create a new batch using those params and send a dealer_issue batch id back. Hmmm.... Lets get into work.
            //few moments later: nops. we got the whole array from parent. hold ma beer
            $this->db->trans_begin();
            $this->db->trans_strict();
            $last_id             = $this->common_model->save($pb_data, 'dealer_issue_batch');
            if ($last_id) {
                $st = array(
                    'success' => true,
                    'msg' => 'Batch created successfully!',
                    'pb_id' => $last_id
                );
                $this->db->trans_commit();
                return ($st);
            } else {
                $st = array(
                    'success' => false,
                    'msg' => 'Error occurred. please contact your system administrator. -PRD1',
                    'pb_id' => 0
                );
                $this->db->trans_rollback();
                return ($st);
            }
        }
    }
}
