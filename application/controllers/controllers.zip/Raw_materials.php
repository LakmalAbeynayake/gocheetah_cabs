<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Raw_Materials extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "raw_materials";
    var $sub_menu_name = "";
    var $title = "Raw Materials";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('products_model');
        $this->load->model('category_model');
        $this->load->model('warehouse_model');
    }
    public function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_raw_mat';
        $data['title']          = $this->title;
        $data['main_category']  = array();  //$this->category_model->get_categories();
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $this->load->view('raw_mat/raw_mat-list', $data);
    }
    public function add()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'add_raw_mats';
        $data['title']          = $this->title;
        $data['main_category']  = $this->category_model->get_categories();
        $data['unit_type']      = $this->products_model->get_units();
        $this->load->view('raw_mat/raw_mat-add', $data);
    }
    public function get_sub_category_by_id()
    {
        $parent_category = $this->input->post('category_id');
        if ($parent_category) {
            $val = $this->category_model->get_sub_category($parent_category);
            if (!empty($val)) {
                echo '<select onchange="raw_mats_load()" name="subcategory" id="subcategory" class="form-control search-select">';
                echo "<option value=''></option>";
                foreach ($val as $key => $lst) {
                    echo "<option value='$lst->sub_cat_id'>$lst->sub_cat_name</option>";
                }
                echo '</select>';
            }
        } else {
            echo NULL;
        }
    }
    public function save_raw_mat()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('product_name', 'Material Name', 'required');
        $this->form_validation->set_rules('product_code', 'Material Code', 'is_unique[product.product_code]');
        
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'status' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $product_code        = $this->products_model->get_ref_number(2, 'RM');
            $product_name        = $this->input->post('product_name');
            $category            = $this->input->post('category');
            $subcategory         = $this->input->post('subcategory');
            $unit                = $this->input->post('unit');
            //$product_cost        = $this->input->post('product_cost');
            $alert_qty           = $this->input->post('alert_qty');
            $product_image       = $this->input->post('product_image');
            $product_description = $this->input->post('product_description');
            $store_position      = $this->input->post('store_position');
            $product_max_qty     = $this->input->post('product_max_qty');
            $product_info        = array(
                'cat_id' => $category,
                'sub_cat_id' => $subcategory,
                'product_name' => $product_name,
                'product_code' => $product_code,
                'product_image' => $product_image,
                'product_alert_qty' => $alert_qty,
                'product_max_qty' => $product_max_qty,
                'product_unit' => $unit,
                /* 'product_cost' => $product_cost, */
                'product_description' => $product_description,
                'store_position' => $store_position,
                'product_type' => 2
            );
            $last_id             = $this->common_model->save($product_info, 'product');
            if ($last_id) {
                $st = array(
                    'success' => true,
                    'validation' => 'Done!',
                    'values' => array(
                        'last_id' => $last_id
                    )
                );
                echo json_encode($st);
            } else {
                $st = array(
                    'status' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
    public function update_raw_mat()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('product_id', 'Product ID', 'required');
        $this->form_validation->set_rules('product_name', 'Product Name', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'success' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $product_id          = $this->input->post('product_id');
            $product_name        = $this->input->post('product_name');
            $category            = $this->input->post('category');
            $subcategory         = $this->input->post('subcategory');
            $unit                = $this->input->post('unit');
            /* $product_cost        = $this->input->post('product_cost'); */
            $alert_qty           = $this->input->post('alert_qty');
            $product_image       = $this->input->post('product_image');
            $product_description = $this->input->post('product_description');
            $store_position      = $this->input->post('store_position');
            $product_max_qty     = $this->input->post('product_max_qty');
            $product_info        = array(
                'cat_id' => $category,
                'sub_cat_id' => $subcategory,
                'product_name' => $product_name,
                'product_image' => $product_image,
                'product_alert_qty' => $alert_qty,
                'product_max_qty' => $product_max_qty,
                'product_unit' => $unit,
                /* 'product_cost' => $product_cost, */
                'product_description' => $product_description,
                'store_position' => $store_position,
                'product_type' => 2
            );
            $last_id             = $this->products_model->update_product($product_info, $product_id);
            if ($last_id) {
                $st = array(
                    'success' => true,
                    'validation' => 'Done!',
                    'values' => array(
                        'last_id' => $last_id
                    )
                );
                echo json_encode($st);
            } else {
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
    function price_filter($amount = '')
    {
        $s = array();
        $s = explode("Rs.", $amount);
        return str_replace(',', '', $s[1]);
    }
    function get_list()
    {
        $this->load->model('stock_model');
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        $filter['search_key_val']        = $search_key['value'];
        $filter['cat_id']       = $this->input->post('cat_id');
        $filter['sub_cat_id']   = $this->input->post('sub_cat_id');
        $filter['warehouse_id']     = $this->input->post('warehouse_id');

        $values        = $this->products_model->get_raw_mats($start, $length, $filter);
        $value_count   = $this->products_model->get_raw_mats('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $products) {
                $row     = array();
                $row[]   = '<div style="margin-bottom: 0px; width: 50px; height: 50px;" class="fileupload-new thumbnail"><img alt="" src="' . $products->product_image . '"></div>';
                $row[]   = $products->product_code;
                $row[]   = $products->product_name;
                $row[]   = $products->cat_name;
                $row[]   = $products->sub_cat_name;
                /* if ($this->common_model->check_permission(117, $this->session->userdata('ss_group_id'), 1)) {
                    $row[] = $products->product_cost;
                }
                $row[]  = $products->product_price; */
                $row[]  = $this->stock_model->get_qty_by_product_id_n_warehouse_id($products->product_id,$filter['warehouse_id']);
                $row[]  = '
                <div class="dropdown show">
                    <a class="btn btn-default dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    ACTIONS <i class="fa fa-chevron-down" aria-hidden="true"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item btn-xs" href="' . base_url() . 'raw_materials/view?product_id=' . $products->product_id . '"> <i class="fa fa-file"></i> Details</a></li>
                        <li><a class="dropdown-item btn-xs" href="' . base_url() . 'raw_materials/edit?product_id=' . $products->product_id . '"> <i class="fa fa-pencil"></i> Edit</a></li>
                    </ul>
                    
                </div>';
                $data[] = $row;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    function suggestions()
    {
        $term = $this->input->get('term');
        $data['sales'] = $this->products_model->get_products_suggestions($term);
        $json = array();
        foreach ($data['sales'] as $row) {
            $extraName = ", Cost Price: " . number_format($row['product_cost'], 2, '.', ',');
            $json_itm = array(
                'value' => $row,
                'label' => $row['product_name'] . " (" . $row['product_code'] . ")$extraName"
            );
            array_push($json, $json_itm);
        }
        echo json_encode($json);
    }
    function view()
    {
        $product_id = $this->input->get('product_id');
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_products';
        $data['title']          = "View product";
        $data['product']  = $this->products_model->get_product_by_id($product_id);
        $this->load->view('raw_mat/raw_mat-info', $data);
    }
    function edit()
    {
        $product_id = $this->input->get('product_id');
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_products';
        $data['title']          = "Edit product";
        $data['product']  = $this->products_model->get_product_by_id($product_id);
        $data['main_category']  = $this->category_model->get_categories();
        $data['unit_type']      = $this->products_model->get_units();
        $this->load->view('raw_mat/raw_mat-edit', $data);
    }
    function get_raw_mat_list()
    {
        $this->load->model('purchases_model');
        $this->load->model('production_model');
        $this->load->model('stock_model');

        $product_id = $this->input->post('product_id');
        $production_qty = $this->input->post('production_qty');
        $warehouse_id = $this->input->post('warehouse_id') ? $this->input->post('warehouse_id'): $this->session->userdata('ss_warehouse_id');
        $recipe  = $this->products_model->get_recipes($product_id);
        $data = array();
        foreach ($recipe as $rc) {
            $row = array();
            //print_r($rc);
            $sel_open   =   '<select class="form-control batch_sel" name="row['.$rc->raw_mat_id.'][batch_id]" id="batch_'.$rc->raw_mat_id.'" data-raw_mat_id="'.$rc->raw_mat_id.'">';
            $sel_close  =   '</select>';
            $options    =   '';
            
            $pur_batches = $this->purchases_model->get_batches(array('product_id' => $rc->raw_mat_id, 'pb_in_use' => 1, 'warehouse_id' => $warehouse_id ));
            if (!empty($pur_batches))
            foreach ($pur_batches as $btch) {
                $bal = $this->stock_model->get_qty($btch->pb_id);
                $options .= '<option value="'.$btch->pb_id.'" data-batch_type="purchase" data-balance="'.floatval($bal).'" data-cost="'.$btch->pb_cost.'">'.$btch->pb_code.'-'.$btch->pb_cost.'</option>';
            }
            $pro_batches = $this->production_model->get_batches(array('product_id' => $rc->raw_mat_id, 'prdb_in_use' => 1, 'warehouse_id' => $warehouse_id ));
            if (!empty($pro_batches))
            foreach ($pro_batches as $btch) {
                $bal = $this->stock_model->get_qty_by_product_id_n_warehouse_id($rc->raw_mat_id,$warehouse_id,$btch->prdb_id,"production");
                //$options .= '<option value="'.$btch->batch_no.'" data-batch_type="purchase" data-balance="'.floatval($bal).'" data-cost="'.$btch->product_cost.'">'.$btch->batch_no.'-'.$btch->product_cost.'</option>';
                $options .= '<option value="'.$btch->prdb_id.'" data-batch_type="production" data-balance="'.floatval($bal).'" data-cost="'.$btch->prdb_cost.'">'.$btch->prdb_code.'-'.$btch->prdb_cost.'</option>';
            }
            $row[] = $rc->product_name.'<input type="hidden" name="row['.$rc->raw_mat_id.'][raw_mat_id]" id="raw_mat_id_'.$rc->raw_mat_id.'" value="'.$rc->raw_mat_id.'">';
            $row[] = $sel_open.$options.$sel_close;
            $row[] = '<span id="available_sp_'.$rc->raw_mat_id.'"></span><input type="hidden" name="row['.$rc->raw_mat_id.'][available_qty]" id="available_'.$rc->raw_mat_id.'">';
            $row[] = '<span id="required_sp_'.$rc->raw_mat_id.'">'.number_format(($production_qty*$rc->raw_mat_qty),2,".",",").'</span><input type="hidden" name="row['.$rc->raw_mat_id.'][required_qty]" id="required_'.$rc->raw_mat_id.'" value="'.($production_qty*$rc->raw_mat_qty).'">';
            $row[] = '<span id="balance_sp_'.$rc->raw_mat_id.'" style="vertical-align: -webkit-baseline-middle;"></span><input type="hidden" name="row['.$rc->raw_mat_id.'][balance_qty]" id="balance_qty'.$rc->raw_mat_id.'" value="">';
            $row[] = '<span id="status_sp_'.$rc->raw_mat_id.'"></span><input type="hidden" name="row['.$rc->raw_mat_id.'][batch_cost]" id="batch_cost_'.$rc->raw_mat_id.'"><input type="hidden" name="row['.$rc->raw_mat_id.'][batch_type]" id="batch_type_'.$rc->raw_mat_id.'">';
            $data[] = $row;
        }
        $output = array(
            'data' => $data
        );
        echo json_encode($output);
    }
}
