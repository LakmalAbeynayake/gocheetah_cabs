<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Purchases extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "purchases";
    var $sub_menu_name = "add_purchases";
    var $title = "Purchase Items";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('purchases_model');
        $this->load->model('category_model');
        $this->load->model('supplier_model');
        $this->load->model('warehouse_model');
        $this->load->model('payments_model');
    }
    public function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        $this->load->view('purchases/purchases-list', $data);
    }
    public function add()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'add_purchases';
        $data['title']          = $this->title;
        $data['supplier']       = $this->supplier_model->get_suppliers();
        $data['main_category']  = $this->category_model->get_categories();
        $data['warehouse']      = $this->warehouse_model->get_warehouses();
        $this->load->view('purchases/purchases-add', $data);
    }
    public function view()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        $id = $this->uri->segment(3);
        $data['purchases_data'] = $this->purchases_model->get_purchase_info($id);
        $data['purchase_items_data']    = $this->purchases_model->get_purchase_items_info($id);
        $this->load->view('purchases/purchases-info', $data);
    }
    public function view_batch()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'batch';
        $data['title']          = $this->title;
        $id = $this->input->get('prdb_id');
        $data['purchases_data'] = $this->purchases_model->get_purchase_batch_info($id);
        $data['purchase_items_data']    = $this->purchases_model->get_purchase_items_info_by_batch_id($id);
        $this->load->view('purchases/purchases-info-batch', $data);
    }

    public function save_purchase()
    {
        $this->load->model('operations_model');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('warehouse_id', 'Product Name', 'required');
        $this->form_validation->set_rules('date_time', 'Product Code', 'is_unique[product.product_code]');
        $this->form_validation->set_rules('supplier_id', 'Supplier Cost', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'status' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $products            = $this->input->post('row');

            if (!count($products) > 0) {
                $st = array(
                    'status' => false,
                    'validation' => "No products received!"
                );
                echo json_encode($st);
                exit;
            }
            $warehouse_id        = $this->input->post('warehouse_id');
            $purchase_total = 0;
            $item_batch = array();
            foreach ($products as $row) {
                $sub_total =  $row['quantity'] * $row['product_cost'];
                $item_data        = array(
                    'product_id' => $row['product_id'],
                    'quantity' => $row['quantity'],
                    'unit_price_wd' => $row['product_cost'],
                    'discount' => $row['discount'],
                    'sub_total' => $sub_total,
                    'discount_cal' => 0,
                    'warehouse_id' => $warehouse_id,
                    'batch_id' => $row['product_batch']
                );
                $purchase_total += $sub_total;
                $item_batch[] = $item_data;
            }

            $reference_no           = $this->common_model->gen_ref_number('warehouse_purchase_id', 'purchases', 'GRN');
            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id);
            $warehouse_purchase_id  = $this->common_model->get_next_value('warehouse_purchase_id', 'purchases', $warehouse_id);

            $supplier_id         = $this->input->post('supplier_id');
            $supp_invocie_no     = $this->input->post('supp_invocie_no');
            $purchase_date_time  = $this->input->post('purchase_date_time');
            $note                = $this->input->post('note');
            $user_id             = $this->session->userdata('ss_user_id');
            $uuid                = $this->input->post('uuid');

            $pur_data        = array(
                'reference_no' => $warehouse_info->code . $reference_no,
                'warehouse_purchase_id' => $warehouse_purchase_id,
                'warehouse_id' => $warehouse_id,
                'supplier_id' => $supplier_id,
                'supp_invocie_no' => $supp_invocie_no,
                'purchase_date_time' => $purchase_date_time,
                'note' => $note,
                'purchase_total' => $purchase_total,
                'user_id' => $user_id,
                'uuid' => $uuid,
            );
            $this->db->trans_begin();
            $this->db->trans_strict();
            $last_id             = $this->common_model->save($pur_data, 'purchases');
            if ($last_id) {
                foreach ($item_batch as $key => $row) {
                    $item_batch[$key]['purchase_id'] = $last_id;
                }
                $item_lst_id             = $this->common_model->save_batch($item_batch, 'purchase_items');
                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'validation' => 'Done!',
                        'values' => array(
                            'last_id' => $last_id
                        )
                    );
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'validation' => 'Error occurred. please contact your system administrator.'
                    );
                    echo json_encode($st);
                }
                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                }
                else{
                    $this->db->trans_commit();
                    $this->operations_model->clear_op($this->session->userdata('ss_user_id'));
                }
            } else {
                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                }
                else{
                    $this->db->trans_commit();
                }
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
    function price_filter($amount = '')
    {
        $s = array();
        $s = explode("Rs.", $amount);
        return str_replace(',', '', $s[1]);
    }
    function get_list()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        $filter[0]     = $search_key['value'];
        $filter[1]     = ($this->input->post('warehouse_id')) ? $this->input->get('warehouse_id') : $this->session->userdata('ss_warehouse_id');
        /* $filter[2]     = $this->input->get('sub_cat_id');
        $filter[3]     = $this->input->get('brand_id'); */
        /* $filter = array(
        'search_key_val'=>     $search_key['value'],
        'cat_id'        =>     $this->input->get('cat_id'),
        'sub_cat_id'    =>    $this->input->get('sub_cat_id'),
        'brand_id'        =>    $this->input->get('brand_id')
        ); */
        $values        = $this->purchases_model->get_purchases($start, $length, $filter);
        $value_count   = $this->purchases_model->get_purchases('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $nestedData[]   = $row->purchase_id;
                $nestedData[]   = $row->purchase_date_time;
                $nestedData[]   = $row->reference_no;
                $nestedData[]   = $row->supp_company_name;
                $nestedData[]   = $row->supp_invocie_no ? $row->supp_invocie_no:'N/A';
                $nestedData[]   = $row->purchase_total;
                $nestedData[]   = $this->payments_model->get_total_paid('grn', $row->purchase_id);
                $nestedData[]   = $row->purchase_total - $this->payments_model->get_total_paid('grn', $row->purchase_id);
                $nestedData[]   = 'N/A';
                $nestedData[]   = '<a href="'.base_url().'purchases/view/'.$row->purchase_id.'" class="btn btn-sm btn-info"><i class="fa fa-file"> Details</a>';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    /**
     * Purchase batch
     */
    function batch(){
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'batch';
        $data['title']          = $this->title;
        $data['warehouse_list'] = $this->warehouse_model->get_warehouses();
        $this->load->view('purchases/purchases-list-batch', $data);
    }
    function get_list_batch()
    {
        $this->load->model('stock_model');
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        
        //$filter[0]     = $search_key['value'];
        $filter['warehouse_id']     = ($this->input->post('warehouse_id')) ? $this->input->post('warehouse_id') : $this->session->userdata('ss_warehouse_id');
        
        /* $filter[2]     = $this->input->get('sub_cat_id');
        $filter[3]     = $this->input->get('brand_id'); */
        /* $filter = array(
            'search_key_val'    =>     $search_key['value'],
            'cat_id'            =>     $this->input->get('cat_id'),
            'sub_cat_id'        =>    $this->input->get('sub_cat_id'),
            'brand_id'          =>    $this->input->get('brand_id')
        ); */
        
        $values        = $this->purchases_model->get_purchases_batches($start, $length, $filter);
        $value_count   = $this->purchases_model->get_purchases_batches('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();

                $buttons = '';
                $btn_enable  = '<a href="#" onClick="enable('.$row->pb_id.')" class="btn btn-sm btn-success"><i class="fa fa-check"></i> Enable</a>';
                $btn_disbale = '<a href="#" onClick="disable('.$row->pb_id.')" class="btn btn-sm btn-warning"><i class="fa fa-minus-circle"></i> Disable</a>';
                $btn_view    = '<a href="'.base_url().'purchases/view_batch?prdb_id='.$row->pb_id.'" class="btn btn-sm btn-info"><i class="fa fa-file"></i> Details</a>';
                
                $buttons .= $row->pb_in_use ? $btn_disbale:$btn_enable;
                $buttons .= $btn_view;

                $nestedData[]   = $row->pb_code;
                $nestedData[]   = $row->product_name;
                $nestedData[]   = $row->pb_added_date_time;
                $nestedData[]   = $row->pb_expire_date != "0000-00-00" ? $row->pb_expire_date : "N/A";
                $nestedData[]   = $row->pb_cost;
                $nestedData[]   = $row->pb_in_use ? "ENABLED":"DISABLED";
                $nestedData[]   = $this->purchases_model->get_purchased_item_qty_by_batch_id($row->pb_id);
                $nestedData[]   = $this->stock_model->get_qty($row->pb_id);
                $nestedData[]   = $buttons;
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    /**
     * save batch
     */
    public function save_batch()
    {
        $this->load->library('form_validation');
        //$this->form_validation->set_rules('warehouse_id', 'Product Name', 'required');
        $this->form_validation->set_rules('uuid', 'uuid', 'is_unique[purchase_batch.uuid]');
        $this->form_validation->set_rules('product_id', 'Product Name', 'required');
        $this->form_validation->set_rules('product_cost', 'product Cost', 'required');
        $this->form_validation->set_rules('warehouse_id', 'Branch', 'required');

        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'success' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            
            $uuid           = $this->input->post('uuid');
            $warehouse_id   = $this->input->post('warehouse_id');
            $product_id     = $this->input->post('product_id');
            $product_cost   = $this->input->post('product_cost');
            $exp_date       = $this->input->post('exp_date');
            $warehouse_info = $this->warehouse_model->get_warehouse_info($warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'));
            $pb_code        = $this->common_model->gen_ref_number_v1('pb_code', 'purchase_batch', $warehouse_info->code.'/PB'.date('ym').'/', array(
                'warehouse_id' => $warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'),
                'date(date_time) >=' => date('Y-m-01')
            ));

            $item_data        = array(
                'product_id' => $product_id,
                'pb_code' => $pb_code,
                'pb_cost' => $product_cost,
                'pb_added_date_time' => date('Y-m-d H:i:s'),
                'pb_expire_date' => $exp_date,
                'pb_in_use' => 1,
                'pb_added_by' => $this->session->userdata('ss_user_id'),
                'warehouse_id' => $warehouse_id,
                'uuid' => $uuid
            );
            
            $last_id             = $this->common_model->save($item_data, 'purchase_batch');
            if ($last_id) {
                
                    $st = array(
                        'success' => true,
                        'validation' => 'Done!',
                        'values' => array(
                            'last_id' => $last_id
                        )
                    );
                    echo json_encode($st);
            } else {
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
}
