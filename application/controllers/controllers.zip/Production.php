<?php
defined('BASEPATH') or exit('No direct script access allowed');
class production extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "production";
    var $sub_menu_name = "add_productions";
    var $title = "Purchase Items";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('production_model');
        $this->load->model('category_model');
        $this->load->model('supplier_model');
        $this->load->model('warehouse_model');
        $this->load->model('payments_model');
    }
    public function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'production_list';
        $data['title']          = $this->title;
        $data['warehouse']      = $this->warehouse_model->get_warehouses();
        $this->load->view('productions/productions-list', $data);
    }
    public function add()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'production_add';
        $data['title']          = $this->title;
        $data['supplier']       = array();
        $data['main_category']  = $this->category_model->get_categories();
        $data['warehouse']      = $this->warehouse_model->get_warehouses();
        $this->load->view('productions/productions-add', $data);
    }
    public function view()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        //$id = $this->uri->segment(3);
        $id = $this->input->get('production_id');

        $data['production_info'] = $this->production_model->get_production($id);
        $data['production_item'] = $this->production_model->get_production_items($id);

        $this->load->view('productions/productions-info', $data);
    }
    public function view_batch()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        $id = $this->input->get('prdb_id');
        $data['production_data'] = $this->production_model->get_production_batch_info($id);
        //print_r($data['production_data']);
        $data['production_items_data']  =   $this->production_model->get_production_items_info_by_batch_id($id);
        //print_r($data['production_items_data']);
        $this->load->view('productions/productions-info-batch', $data);
    }
    public function create_production_batch()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('warehouse_id', 'Product Name', 'required');
        $this->form_validation->set_rules('production_date_time', 'Date', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'success' => false,
                'msg' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $production_date_time  = $this->input->post('production_date_time');
            $note                = $this->input->post('note');
            $warehouse_id        = $this->input->post('warehouse_id');
            $uuid                = $this->input->post('uuid');
            $user_id             = $this->session->userdata('ss_user_id');
            $production_total = 0;

            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'));
            $reference_no        = $this->common_model->gen_ref_number_v1('reference_no', 'productions', $warehouse_info->code . '/PRD' . date('ym') . '/', array(
                'warehouse_id' => $warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'),
                'date(date_time) >=' => date('Y-m-01')
            ));


            $pur_data        = array(
                'reference_no' => $reference_no,
                'warehouse_id' => $warehouse_id,
                'production_date_time' => $production_date_time,
                'note' => $note,
                'production_total' => $production_total,
                'user_id' => $user_id,
                'uuid' => $uuid,
            );
            $this->db->trans_begin();
            $this->db->trans_strict();
            $last_id             = $this->common_model->save($pur_data, 'productions');
            if ($last_id) {
                $st = array(
                    'success' => true,
                    'msg' => 'Batch created successfully!',
                    'url' => 'production/set_raw_mats?production_id=' . $last_id,
                    'values' => array(
                        'last_id' => $last_id
                    )
                );
                $this->db->trans_commit();
                echo json_encode($st);
            } else {
                $st = array(
                    'success' => false,
                    'msg' => 'Error occurred. please contact your system administrator. -H2'
                );
                $this->db->trans_rollback();
                echo json_encode($st);
            }
        }
    }
    public function save_production()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('production_id', 'Production ID', 'required');
        $this->form_validation->set_rules('product_id', 'Product ID', 'required');
        $this->form_validation->set_rules('batch_no', 'Batch No', 'required');
        $this->form_validation->set_rules('production_qty', 'Manufacturing Quantity', 'required');
        $this->form_validation->set_rules('warehouse_id', 'Warehouse ID', 'required');
        $this->form_validation->set_rules('expire_date', 'Expiry ID', 'required');
        $this->form_validation->set_rules('mrp', 'MRP', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'success' => false,
                'msg' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $raw_mats            = $this->input->post('row');
            /* echo "<pre>";
            print_r($raw_mats);
            echo "</pre>";
            exit; */
            if (!count($raw_mats) > 0) {
                $st = array(
                    'success' => false,
                    'msg' => "No Row-materials data received!"
                );
                echo json_encode($st);
                exit;
            }
            $batch_no       = $this->input->post('batch_no');
            $product_id     = $this->input->post('product_id');
            $production_qty = $this->input->post('production_qty');
            $production_id  = $this->input->post('production_id');
            $warehouse_id   = $this->input->post('warehouse_id');
            $expire_date    = $this->input->post('expire_date');
            $uuid           = $this->input->post('uuid');
            $mrp            = $this->input->post('mrp');
            $user_id        = $this->session->userdata('ss_user_id');

            $cost_total = 0;
            $unit_cost_total = 0;
            $production_raw_materials = array();
            foreach ($raw_mats as $row) {
                $item_data        = array(
                    'product_id' => $product_id,
                    'raw_mat_id' => $row['raw_mat_id'],
                    'raw_mat_qty' => $row['required_qty'],
                    'batch_id' => $row['batch_id'], //purchase_batch_id
                    'batch_type' => $row['batch_type'], //purchase_batch_id
                    'purchase_batch_cost' => $row['batch_cost'],
                    'sub_total_cost' => $row['required_qty'] * $row['batch_cost'],
                    'warehouse_id' => $warehouse_id
                );
                $cost_total += ($row['required_qty'] * $row['batch_cost']);
                $unit_cost_total += $row['batch_cost'];
                $production_raw_materials[] = $item_data;
            }
            /* Batch Validation */
            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'));
            $reference_no        = $this->common_model->gen_ref_number_v1('prdb_ref_no', 'production_batch', $warehouse_info->code . 'PRB/' . date('ym') . '/', array(
                'warehouse_id' => $warehouse_id ? $warehouse_id : $this->session->userdata('ss_warehouse_id'),
                'date(date_time) >=' => date('Y-m-01')
            ));
            $production_batch_data = array(
                'product_id' => $product_id,
                'prdb_ref_no' => $reference_no,
                'prdb_code' => $batch_no,
                'prdb_cost' => $cost_total,
                'prdb_mrp' => $mrp,
                'prdb_added_date_time' => date('Y-m-d H:i:s'),
                'expire_date' => $expire_date,
                'prdb_in_use' => 1,
                'prdb_added_by' => $this->session->userdata('ss_user_id'),
                'warehouse_id' => $warehouse_id,
                'date_time' => date("Y-m-d H:i:s"),
                'uuid' => $uuid
            );
            $is_pb_valid = $this->validate_production_batch($production_batch_data);
            if (!$is_pb_valid['success']) {
                $st = array(
                    'success' => false,
                    'msg' => "Invalid batch for cost!"
                );
                echo json_encode($st);
            }
            /* End batch validation */
            $main_product_data  = array(
                'production_id' => $production_id,
                'production_batch_id' => $is_pb_valid['pb_id'],
                'product_id' => $product_id,
                'batch_no' => $batch_no,
                'product_cost' => $unit_cost_total,
                'production_quantity' => $production_qty,
                'warehouse_id' => $warehouse_id,
                'uuid' => $uuid,
                'user_id' => $user_id
            );
            $this->db->trans_begin();
            $this->db->trans_strict();
            $production_item_id             = $this->common_model->save($main_product_data, 'production_items');
            if ($production_item_id) {
                foreach ($production_raw_materials as $key => $row) {
                    $production_raw_materials[$key]['production_item_id'] = $production_item_id;
                }
                $item_lst_id             = $this->common_model->save_batch($production_raw_materials, 'production_raw_materials');
                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'msg' => 'Added Successfully',
                        'url' => 'production/set_raw_mats?production_id=' . $production_id,
                        'values' => array(
                            'production_id' => $production_id
                        )
                    );
                    $this->db->trans_commit();
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'msg' => 'Error occurred. please contact your system administrator. -H1'
                    );
                    $this->db->trans_rollback();
                    echo json_encode($st);
                }
            } else {
                $st = array(
                    'success' => false,
                    'msg' => 'Error occurred. please contact your system administrator. -H2'
                );
                $this->db->trans_rollback();
                echo json_encode($st);
            }
        }
    }
    function price_filter($amount = '')
    {
        $s = array();
        $s = explode("Rs.", $amount);
        return str_replace(',', '', $s[1]);
    }
    function get_list()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        $filter = array(
            'search_key_value' => $search_key['value'],
            'warehouse_id' => ($this->input->post('warehouse_id')) ? $this->input->get('warehouse_id') : $this->session->userdata('ss_warehouse_id'),
        );

        /* $filter[2]     = $this->input->get('sub_cat_id');
        $filter[3]     = $this->input->get('brand_id'); */
        /* $filter = array(
        'search_key_val'=>     $search_key['value'],
        'cat_id'        =>     $this->input->get('cat_id'),
        'sub_cat_id'    =>    $this->input->get('sub_cat_id'),
        'brand_id'        =>    $this->input->get('brand_id')
        ); */
        $values        = $this->production_model->get_productions($start, $length, $filter);
        $value_count   = $this->production_model->get_productions('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $nestedData[]   = $row->reference_no;
                $nestedData[]   = date("Y-m-d H:i:s a", strtotime($row->production_date_time));
                $nestedData[]   = $row->note ? $row->note : 'N/A';
                $nestedData[]   = $row->production_status ? 'ENABLED' : 'DISABLED';
                $nestedData[]   = '<div style="display: flex;justify-content: space-evenly;">
                <a class="btn btn-sm btn-warning" href="' . base_url() . 'production/set_raw_mats?production_id=' . $row->production_id . '">Add Products</a>
                <a class="btn btn-sm btn-success" href="' . base_url() . 'production/view?production_id=' . $row->production_id . '"> View Production</a>
                </div>';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    /* ASSIGN RAW MATERIALS */
    function set_raw_mats()
    {
        $this->load->model('products_model');
        $production_id = $this->input->get('production_id');

        $data['product_id']     = $this->input->get('product_id');
        $data['production_qty'] = $this->input->get('production_qty');
        $data['product_name']   = $this->input->get('product_name');

        $data['production_info'] = $this->production_model->get_production($production_id);
        $data['production_item'] = $this->production_model->get_production_items($production_id);
        $data['main_menu_name'] = 'production';
        $data['sub_menu_name']  = 'production_add';
        $data['title']          = $this->title;
        if (empty($data['production_info']))
            show_404();
        $this->load->view('productions/productions-set_raw_mats', $data);
    }
    function batch()
    {
        $data['main_menu_name'] = 'production';
        $data['sub_menu_name']  = 'production_batch';
        $data['title']          = 'Production Batches';
        $this->load->view('productions/productions-list_batch', $data);
    }
    function get_list_batch()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');

        //$filter[0]     = $search_key['value'];
        $filter['warehouse_id']     = ($this->input->post('warehouse_id')) ? $this->input->post('warehouse_id') : $this->session->userdata('ss_warehouse_id');

        /* $filter[2]     = $this->input->get('sub_cat_id');
        $filter[3]     = $this->input->get('brand_id'); */
        /* $filter = array(
            'search_key_val'    =>     $search_key['value'],
            'cat_id'            =>     $this->input->get('cat_id'),
            'sub_cat_id'        =>    $this->input->get('sub_cat_id'),
            'brand_id'          =>    $this->input->get('brand_id')
        ); */

        $values        = $this->production_model->get_production_batches($start, $length, $filter);
        $value_count   = $this->production_model->get_production_batches('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $buttons = '';
                $btn_enable = '<a href="#" onClick="enable(' . $row->prdb_id . ')" class="btn btn-sm btn-success"><i class="fa fa-check"></i> Enable</a>';
                $btn_disbale = '<a href="#" onClick="disable(' . $row->prdb_id . ')" class="btn btn-sm btn-warning"><i class="fa fa-minus-circle"></i> Disable</a>';
                $btn_view    = '<a href="' . base_url() . 'production/view_batch?prdb_id=' . $row->prdb_id . '" class="btn btn-sm btn-info"><i class="fa fa-file"></i> Details</a>';

                $buttons .= $row->prdb_in_use ? $btn_disbale : $btn_enable;
                $buttons .= $btn_view;
                $mfq = $this->production_model->get_manufactured_qty_by_prdb_id($row->prdb_id);
                $nestedData[]   = $row->prdb_code;
                $nestedData[]   = $row->product_name;
                $nestedData[]   = $row->prdb_added_date_time;
                $nestedData[]   = $row->expire_date;
                $nestedData[]   = $row->prdb_cost;
                $nestedData[]   = $mfq->production_quantity;
                $nestedData[]   = $row->prdb_in_use ? "ENABLED" : "DSIABLED";
                $nestedData[]   = '<div style="display: flex;justify-content: space-evenly;">' . $buttons . '</div>';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
    /* Open production sheet*/
    function open()
    {
        $id = $this->input->get('id');
        $response = $this->production_model->open($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Opened Successfully" : "Error"
        ));
    }
    /* Close production sheet*/
    function close()
    {
        $id = $this->input->get('id');
        $response = $this->production_model->close($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Closed Successfully" : "Error"
        ));
    }
    /* enable production batch*/
    function enable()
    {
        $id = $this->input->get('id');
        $response = $this->production_model->enable($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Enabled Successfully" : "Error"
        ));
    }
    /* disable production batch*/
    function disable()
    {
        $id = $this->input->get('id');
        $response = $this->production_model->disable($id);
        echo json_encode(array(
            'success' => $response ? true : false,
            'msg' => $response ? "Disabled Successfully" : "Error"
        ));
    }
    function validate_production_batch($pb_data)
    {
        //print_r($pb_data);exit;
        $pro_batch_id = 0;
        $pb_info = $this->production_model->get_production_batch_info_by_batch_no($pb_data['prdb_code'], $pb_data['prdb_cost'], $pb_data['warehouse_id']);
        //ANYTHING???
        if (!empty($pb_info)) {
            // YES. That means, there IS a batch so lets check if it's the same product that we're trying to allocate
            if ($pb_info->product_id == $pb_data['product_id']) {
                //oo yeah its same. good to go. lets return those numbers so their job will be easy
                return array(
                    'success' => true,
                    'msg' => 'Good to go',
                    'pb_id' => $pb_info->prdb_id
                );
            } else {
                //oho no its not. Back off dude!!!!
                return array(
                    'success' => false,
                    'msg' => 'This batch no is already assigned for another product!'
                );
            }
        } else {
            //NO. That means, we have to create a new batch using those params and send a production batch id back. Hmmm.... Lets get into work.
            //few moments later: nops. we got the whole array from parent. hold ma beer
            $this->db->trans_begin();
            $this->db->trans_strict();
            $last_id             = $this->common_model->save($pb_data, 'production_batch');
            if ($last_id) {
                $st = array(
                    'success' => true,
                    'msg' => 'Batch created successfully!',
                    'pb_id' => $last_id
                );
                $this->db->trans_commit();
                return ($st);
            } else {
                $st = array(
                    'success' => false,
                    'msg' => 'Error occurred. please contact your system administrator. -PRD1',
                    'pb_id' => 0
                );
                $this->db->trans_rollback();
                return ($st);
            }
        }
    }
}
