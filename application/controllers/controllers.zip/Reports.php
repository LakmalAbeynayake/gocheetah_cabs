<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Reports extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "reports";
    var $sub_menu_name = "reports";
    var $title = "Reports";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('customers_model');
        $this->load->model('purchases_model');
        $this->load->model('category_model');
        $this->load->model('supplier_model');
        $this->load->model('warehouse_model');
        $this->load->model('payments_model');
        $this->load->model('sales_model');
        $this->load->model('products_model');
        $this->load->model('user_model');
    }
    public function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_purchases';
        $data['title']          = $this->title;
        $this->load->view('purchases/purchases-list', $data);
    }
    function sales()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'rep_sales';
        $data['title']          = $this->title;
        $data['customers']  = $this->customers_model->get_all_customers();
        $data['warehouse']  = $this->warehouse_model->get_warehouses();
        $data['users']      = $this->user_model->get_users();
        $this->load->view('reports/sales', $data);
    }
    function payments()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'rep_payments';
        $data['title']          = $this->title;
        $data['customers'] = $this->customers_model->get_all_customers();
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $data['users'] = $this->user_model->get_users();
        $this->load->view('reports/payments', $data);
    }
    function stock()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'rep_stock';
        $data['title']          = $this->title;
        $data['customers'] = $this->customers_model->get_all_customers();
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $data['users'] = $this->user_model->get_users();
        $data['main_category']  = $this->category_model->get_categories();
        $this->load->view('reports/stock', $data);
    }
    /* get sales summary*/
    function get_sales_summary()
    {
        $success = true;
        $filter = array();
        $filter['sale_date_from']    = $this->input->post('sale_date_from');
        $filter['sale_date_to']    = $this->input->post('sale_date_to');
        $filter['user_id'] = $this->input->post('user_id');
        $filter['warehouse_id'] = $this->input->post('warehouse_id');

        $values        = $this->sales_model->get_sales_summary($filter);

        $sales_total = ($values->sale_total != null) ? $values->sale_total : 0;
        $sale_cost = ($values->sale_cost != null) ? $values->sale_cost : 0;

        $profit = $sales_total - $sale_cost;
        $loss   = (($sale_cost - $sales_total) > 0) ? $sale_cost - $sales_total : 0;

        $profit_precentage = 0;
        $loss_precentage = 0;
        if ($profit > 0) {
            $profit_precentage = $profit / $sale_cost * 100;
        }
        if ($loss > 0) {
            $profit_precentage = $loss / $sale_cost * 100;
        }

        $json_data = array(
            "success" => $success,
            "values" => array(
                'sales_total' => $sales_total,
                'sales_cost' => $sale_cost,
                'profit' => $profit,
                'loss' => $loss,
                'profit_prec' => $profit_precentage,
                'loss_prec' => $loss_precentage,
            )
        );
        echo json_encode($json_data);
    }
    function get_payments_summary()
    {
        $success = true;

        $filter = array();
        $filter['date_from']    = $this->input->post('date_from');
        $filter['date_to']      = $this->input->post('date_to');
        $filter['paid_by']      = $this->input->post('paid_by');
        $filter['pymnt_type']   = $this->input->post('pymnt_type');
        $filter['user_id']      = $this->input->post('user_id');
        $filter['warehouse_id'] = $this->input->post('warehouse_id');

        $values        = $this->payments_model->get_payment_summary($filter);
        
        $json_data = array(
            "success" => $success,
            "values" => $values->pymnt_amount
        );
        echo json_encode($json_data);
    }
    function get_payments()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        
        $filter = array();
        $filter['date_from']    = $this->input->post('date_from');
        $filter['date_to']      = $this->input->post('date_to');
        $filter['paid_by']      = $this->input->post('paid_by');
        $filter['pymnt_type']   = $this->input->post('pymnt_type');
        $filter['user_id']      = $this->input->post('user_id');
        $filter['warehouse_id'] = $this->input->post('warehouse_id');

        $values        = $this->payments_model->get_payments($start, $length, $filter);
        $value_count   = $this->payments_model->get_payments('', '', $filter);
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData        = array();
                $nestedData[]      = $row->pymnt_ref_no;
                $nestedData[]      = $row->pymnt_date_time;
                $nestedData[]      = $row->pymnt_type;
                $nestedData[]      = $row->pay_by;
                $nestedData[]      = $row->pymnt_amount;
                $nestedData[]      = $row->user_first_name.' '.$row->user_last_name;
                $nestedData[]      = $row->name;
                $data[]               = $nestedData;
            }
        }

        $json_data = array(
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );
        echo json_encode($json_data);
    }
    function get_stock(){

        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');

        //$filter['search_key_val']        = $search_key['value'];
        $filter['cat_id']       = $this->input->post('cat_id');
        $filter['sub_cat_id']   = $this->input->post('sub_cat_id');
        $filter['warehouse_id']     = $this->input->post('warehouse_id');


        $values        = $this->products_model->get_products($start, $length, $filter);
        $value_count   = $this->products_model->get_products('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $products) {
                $product_id =  $products->product_id;
                $warehouse_id = $filter['warehouse_id'];

                $purchases = $this->products_model->get_purchased_qty($product_id,$warehouse_id);
                $sold = $this->products_model->get_sold_qty($product_id,$warehouse_id);
                $return = $this->products_model->get_return_qty($product_id,$warehouse_id);
                $trans_in = $this->products_model->get_transfer_in_qty($product_id,$warehouse_id);
                $trans_out = $this->products_model->get_transfer_out_qty($product_id,$warehouse_id);
                $damaged =  $this->products_model->get_damaged_qty($product_id,$warehouse_id);

                $purchases = intval($purchases);  
                $sold = intval($sold);  
                $return = intval($return);  
                $trans_in = intval($trans_in);  
                $trans_out = intval($trans_out);  
                $damaged = intval($damaged);  

                $balance = $purchases -$sold +$return + $trans_in -$trans_out + $damaged;


                $row     = array();
                $row[]   = $products->product_code;
                $row[]   = $products->product_name;
                $row[]   = $purchases;
                $row[]   = $sold;
                $row[]   = $return;
                $row[]   = $trans_in;
                $row[]   = $trans_out;
                $row[]   = $balance;
                $data[] = $row;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
}
