<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('sales_model');
        $this->load->model('payments_model');
        $this->load->model('products_model');
    }
    public function index()
    {
        $this->load->model('warehouse_model');
        $this->load->model('customers_model');
        $data['main_menu_name'] = 'sales';
        $data['sub_menu_name']  = 'list_sales';
        $data['title']  = 'Sales';
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $data['customers'] = $this->customers_model->get_all_customers();
        $this->load->view('sales/sales-list', $data);
    }
    function get_list()
    {
        $start         = $this->input->post('start');
        $length        = $this->input->post('length');
        $search_key    = $this->input->post('search');
        $sfilter = array();
        $sfilter['search_key']      = $search_key['value'];
        $sfilter['reference_no']    = $this->input->post('reference_no');
        $sfilter['customer_id']     = $this->input->post('customer_id');
        $sfilter['sale_date']       = $this->input->post('sale_date');
        $sfilter['sale_date_from']  = $this->input->post('sale_date_from');
        $sfilter['sale_date_to']    = $this->input->post('sale_date_to');
        $sfilter['user_id']         = $this->input->post('user_id');
        $sfilter['warehouse_id']    = $this->input->post('warehouse_id');

        $values        = $this->sales_model->get_sales($start, $length, $sfilter);
        $value_count   = $this->sales_model->get_sales('', '', $sfilter);
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData        = array();
                $sale_id           = $row->sale_id;
                $total_paid_amount = $this->sales_model->get_total_paid_by_sale_id($sale_id);
                $return_tot_amt    = 0;
                $to_be_paid        = $row->sale_total - $return_tot_amt;
                $nestedData[]      = $row->sale_id;
                $nestedData[]      = $row->sale_date_time;
                $nestedData[]      = $row->sale_reference_no;
                $nestedData[]      = $row->cus_name;
                $nestedData[]      = $row->sale_total;
                $nestedData[]      = $total_paid_amount;
                $nestedData[]      = $row->sale_total - $total_paid_amount;
                if (empty($total_paid_amount)) {
                    $pay_st = '<span class="label label-warning">Pending</span>';
                } else {
                    if ($total_paid_amount >= $to_be_paid) {
                        $pay_st = '<span class="label label-success">Paid</span>';
                    } else {
                        $pay_st = '<span class="label label-info">Partial</span>';
                    }
                }
                $key = "default";
                $protocol = "default";
                $domain = "127.0.0.1/stock_manager/";
                $path = "sales/get_json?sale_id=".$sale_id;
                $dataType = "text/html";
                $printerName = "default";
                
                $pay_st = '<a href="skyprint:?key='.$key.'&protocol='.$protocol.'&domain='.$domain.'&path='.$path.'&dataType='.$dataType.'&printerName='.$printerName.'">LOCAL PRINT</a>';
                $nestedData[]         = $pay_st;
                
                $dropdown = '<div class="btn-group text-left">
                                <button data-toggle="dropdown" class="btn btn-default btn-xs btn-primary dropdown-toggle" type="button">Actions <span class="caret"></span></button>
                                <ul role="menu" class="dropdown-menu pull-right">';

                $li_details = '<li><a href="' . base_url() . 'sales/view?sale_id=' . $sale_id . '"><i class="fa fa-file-text"></i> Sale Details</a></li>';
                $li_return_details = '<li><a href="' . base_url() . 'sales/return_sale?sale_id=' . $sale_id . '"><i class="fa fa-file-text"></i> Return Sale</a></li>';
                $dropdown_close = '</ul></div>';
                $nestedData[]         = $dropdown . $li_details . $li_return_details . $dropdown_close;
                $data[]               = $nestedData;
            }
        }

        $json_data = array(
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );
        echo json_encode($json_data);
    }
    function get_json(){
        $sale_id = $this->input->get('sale_id');
        $data['info'] = $this->sales_model->get_sale_info($sale_id);
        $data['items'] = $this->sales_model->get_sale_item_info($sale_id);
        $data['payments'] = $this->payments_model->get_paid('sale', $sale_id);
        header('Content-type: application/json');
        echo json_encode($data);
    }
    function view(){
        $sale_id = $this->input->get('sale_id');
        $this->load->model('warehouse_model');
        $this->load->model('customers_model');
        $data['main_menu_name'] = 'sales';
        $data['sub_menu_name']  = 'list_sales';
        $data['title']  = 'Sale info';
        $data['sale'] = $this->sales_model->get_sale_info($sale_id);
        $data['items'] = $this->sales_model->get_sale_item_info($sale_id);
        $data['payments'] = $this->payments_model->get_paid('sale', $sale_id);
        $this->load->view('sales/sales-view', $data);
    }
    function return_sale(){
        $sale_id = $this->input->get('sale_id');
        $this->load->model('warehouse_model');
        $this->load->model('customers_model');
        $data['main_menu_name'] = 'sales';
        $data['sub_menu_name']  = 'list_sales';
        $data['title']  = 'Sale Return';
        $data['sale'] = $this->sales_model->get_sale_info($sale_id);
        $data['payments'] = $this->payments_model->get_paid('sale', $sale_id);
        $this->load->view('sales/sales-return', $data);
    }
    function suggestions()
    {
        $term = $this->input->get('term');
        $sales_id = $this->input->get('sale_id');
        $data['sales'] = $this->sales_model->get_products_suggestions($term,$sales_id);
        $json = array();
        foreach ($data['sales'] as $row) {
            $extraName = ", Sale Price: " . number_format($row['product_cost'], 2, '.', ',');
            $json_itm = array(
                'value' => $row,
                'label' => $row['product_name'] . " (" . $row['product_code'] . ")$extraName"
            );
            array_push($json, $json_itm);
        }
        echo json_encode($json);
    }
    function save_return()
    {
        $this->load->model('warehouse_model');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('sale_id', 'Sale ID', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'status' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $products            = $this->input->post('row');
            if (!count($products) > 0) {
                $st = array(
                    'status' => false,
                    'validation' => "No products received!"
                );
                echo json_encode($st);
                exit;
            }
            $warehouse_id        = $this->session->userdata('ss_warehouse_id');

            $trnsfr_total = 0;
            $item_batch = array();
            foreach ($products as $row) {
                $sub_total =  $row['quantity'] * $row['product_cost'];
                $item_data        = array(
                    'product_id' => $row['product_id'],
                    'quantity' => $row['quantity'],
                    'unit_price' => $row['product_cost'],
                    'total_price' => $sub_total,
                    'warehouse_id' => $warehouse_id
                );
                $trnsfr_total += $sub_total;
                $item_batch[] = $item_data;
            }
            
            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id);
            $reference_no           = $this->common_model->gen_ref_number('sl_rtn_id', 'sales_return', 'SLR');

            $sl_rtn_datetime     = date("Y-m-d H:i:s");
            $sale_id                = $this->input->post('sale_id');
            $user_id             = $this->session->userdata('ss_user_id');
            $uuid                = $this->input->post('uuid');
            $warehouse_sl_rtn_id  = $this->common_model->get_next_value('warehouse_sl_rtn_id', 'sales_return', $warehouse_id);

            $pur_data        = array(
                'sl_rtn_reference_no' => $warehouse_info->code .$reference_no,
                'warehouse_sl_rtn_id' => $warehouse_sl_rtn_id,
                'sale_id' => $sale_id,
                'warehouse_id' => $warehouse_id,
                'sl_rtn_datetime' => $sl_rtn_datetime,
                'sl_rtn_total' => $trnsfr_total,
                'user_id' => $user_id,
                'uuid' => $uuid,
            );
            $last_id             = $this->common_model->save($pur_data, 'sales_return');
            if ($last_id) {
                foreach ($item_batch as $key => $row) {
                    $item_batch[$key]['sl_rtn_id'] = $last_id;
                }
                $item_lst_id             = $this->common_model->save_batch($item_batch, 'sales_return_items');
                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'validation' => 'Done!',
                        'value' => array(
                            'last_id' => $last_id
                        )
                    );
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'validation' => 'Error occurred. please contact your system administrator.'
                    );
                    echo json_encode($st);
                }
            } else {
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
    function returns(){
        $this->load->model('warehouse_model');
        $this->load->model('customers_model');
        $data['main_menu_name'] = 'sales';
        $data['sub_menu_name']  = 'list_return';
        $data['title']  = 'Sales returns';
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $data['customers'] = $this->customers_model->get_all_customers();
        $this->load->view('sales/sales-return-list', $data);
    }
    /* add sales view load */
    function add(){
        $data['main_menu_name'] = 'sales';
        $data['sub_menu_name']  = 'add_sales';
        $data['title']          = 'Add sale';
        $data['customer']       = $this->customers_model->get_all_customers();
        $data['main_category']  = $this->category_model->get_categories();
        $data['warehouse']      = $this->warehouse_model->get_warehouses();
        $this->load->view('sales/sales-add', $data);
    }
}
