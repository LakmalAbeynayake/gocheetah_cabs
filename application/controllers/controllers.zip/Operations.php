<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Operations extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('operations_model');
        $this->load->model('common_model');
        $this->load->model('purchases_model');
        $this->load->model('category_model');
        $this->load->model('supplier_model');
        $this->load->model('warehouse_model');
        $this->load->model('payments_model');
    }
    // [{"pd_id":"5","pb_code":"B1PB000003","pd_cost":"12"},{"pd_id":"1","pb_code":"B1PB000001","pd_cost":"
    /*
    
    Purchases 
    
    */
    //purchase header
    function check_purchase()
    {
        $success = false;
        $data = array(
            'success' => $success
        );
        $purchases = $this->operations_model->get_purchases();
        if (!empty($purchases)) {
            $purchase_items = $this->operations_model->get_purchases_items($purchases->op_id);
            /* echo "<pre>";
            print_r($purchase_items[0]->batches);
            echo "</pre>"; */

            foreach($purchase_items as $key=>$pi){
                //print_r($pi);
                //$purchase_items[$key]->batches = preg_replace('/\[[^\]]*\]/', '', json_encode($pi), 1);;
                $purchase_items[$key]->batches = json_decode($pi->batches);
            }

            /* echo "<pre>";
                print_r($purchase_items[0]->batches);
            echo "</pre>";  */

            
            $data['main'] = $purchases;
            $data['items'] = $purchase_items;
            $success = true;
            $data['success'] = $success;
        }
        echo json_encode($data);
    }
    function set_purchase()
    {
        $success = false;

        $warehouse_id       = $this->input->post('warehouse_id');
        $supplier_id        = $this->input->post('supplier_id');
        $op_supp_invocie_no        = $this->input->post('op_supp_invocie_no');
        $op_id = 0;

        $this->load->library('form_validation');
        $this->form_validation->set_rules('warehouse_id', 'Warehouse', 'required');
        $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
        if ($this->form_validation->run() == FALSE) {
            $success = false;
        } else {
            $purchases = $this->operations_model->get_purchases();
            if (!empty($purchases)) {
                $op_id = $purchases->op_id;
                $op_data = array(
                    //"op_date_time" => date("Y-m-d H:i:s"),
                    "op_supplier_id" => $supplier_id,
                    "op_supp_invocie_no" => $op_supp_invocie_no,
                    "warehouse_id" => $warehouse_id,
                    "op_user_id" => $this->session->userdata('ss_user_id')
                );
                $op_id = $this->operations_model->handle_purchase($op_data, $op_id);
                if ($op_id > 0)
                    $success = true;
            } else {
                $op_data = array(
                    "op_date_time" => date("Y-m-d H:i:s"),
                    "op_supplier_id" => $supplier_id,
                    "op_supp_invocie_no" => $op_supp_invocie_no,
                    "warehouse_id" => $warehouse_id,
                    "op_user_id" => $this->session->userdata('ss_user_id')
                );
                $op_id = $this->operations_model->handle_purchase($op_data);
                if ($op_id > 0)
                    $success = true;
            }
        }
        echo json_encode(array(
            'success' => $success,
            'op_id' => $op_id
        ));
    }
    function set_purchase_items()
    {
        $success = false;
        $current_quantity = 0;
        $product_id = 0;

        /* item fields */
        $op_product_id  = $this->input->post('product_id');
        $op_quantity    = $this->input->post('quantity');
        $op_product_price    = $this->input->post('price');
        $batches    = $this->input->post('batches');
        $change_method    = $this->input->post('change_method');

        /* $json = json_encode($batches);
        print_r($json); */

        $op_id = 0;
        $purchases = $this->operations_model->get_purchases();
        if (!empty($purchases)) {
            $op_id = $purchases->op_id;
        } else {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('warehouse_id', 'Warehouse', 'required');
            $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
            if ($this->form_validation->run() == FALSE) {
                $success = false;
                $op_id = 0;
                $op_product_id = 0;
                $current_quantity = 0;
            }
        }
        if ($op_id) {
            $success = true;
            if ($op_product_id && $op_quantity) {
                switch ($change_method) {
                    case "add":
                        $current_qty = 0;
                        $current_qty = $this->operations_model->get_purchases_item_quantity($op_id, $op_product_id);
                        if (is_numeric($current_qty) && $current_qty > 0) {
                            $current_qty += floatVal($op_quantity);
                            $op_items_data = array(
                                "op_quantity" => $current_qty
                            );
                            $success = $this->operations_model->handle_purchase_items($op_items_data, $op_id, $op_product_id);
                            $current_quantity = $current_qty;
                        } else if (is_numeric($op_quantity) && $op_quantity > 0) {
                            $op_items_data = array(
                                "op_purchase_id" => $op_id,
                                "op_product_id" => $op_product_id,
                                "op_product_price" => $op_product_price,
                                "op_quantity" => $op_quantity,
                                "op_batches" => json_encode($batches),
                                "op_user_id" => $this->session->userdata('ss_user_id')

                            );
                            $success = $this->operations_model->handle_purchase_items($op_items_data, "", "");
                            $current_quantity = $op_quantity;
                        }
                        break;
                    case "update":
                        $op_items_data = array(
                            "op_quantity" => $op_quantity
                        );
                        $success = $this->operations_model->handle_purchase_items($op_items_data, $op_id, $op_product_id);
                        $current_quantity = $op_quantity;
                        break;
                    case "delete":
                        $op_items_data = array(
                            "product_id" => $op_product_id
                        );
                        $success = $this->operations_model->delete_row($op_items_data, $op_id, $op_product_id);
                        $current_quantity = 0;
                        break;
                    default:
                        $success = false;
                        break;
                }
            }
        }

        echo json_encode(array(
            'success' => $success,
            'op_id' => $op_id,
            'product_id' => $op_product_id,
            'current_quantity' => $current_quantity
        ));
    }
    function delete_row()
    {
        $product_id = $this->input->post('product_id');
        $op_purchase_id = 0;
        $purchases = $this->operations_model->get_purchases();
        if (!empty($purchases)) {
            $op_purchase_id = $purchases->op_id;
        }

        $success = $this->operations_model->delete_row($op_purchase_id, $product_id);
        echo json_encode(array(
            'success' => $success
        ));
    }
    function clear_op(){
        $this->operations_model->clear_op($this->session->userdata('ss_user_id'));
    }
    /**
     * PRODUCTION OPERATIONS - DUMMY
     */
    function set_production()
    {
        echo json_encode(array(
            'success' => true,
            'op_id' => 1
        ));
        exit;
        $success = false;

        $warehouse_id       = $this->input->post('warehouse_id');
        $op_id = 0;

        $this->load->library('form_validation');
        $this->form_validation->set_rules('warehouse_id', 'Warehouse', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            $success = false;
        } else {
            $purchases = $this->operations_model->get_purchases();
            if (!empty($purchases)) {
                $op_id = $purchases->op_id;
                $op_data = array(
                    //"op_date_time" => date("Y-m-d H:i:s"),
                    "warehouse_id" => $warehouse_id,
                    "op_user_id" => $this->session->userdata('ss_user_id')
                );
                $op_id = $this->operations_model->handle_purchase($op_data, $op_id);
                if ($op_id > 0)
                    $success = true;
            } else {
                $op_data = array(
                    "op_date_time" => date("Y-m-d H:i:s"),
                    "warehouse_id" => $warehouse_id,
                    "op_user_id" => $this->session->userdata('ss_user_id')
                );
                $op_id = $this->operations_model->handle_purchase($op_data);
                if ($op_id > 0)
                    $success = true;
            }
        }
        echo json_encode(array(
            'success' => $success,
            'op_id' => $op_id
        ));
    }
}
