<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Damages extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    var $main_menu_name = "damages";
    var $sub_menu_name = "damages";
    var $title = "Damaged Items";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('common_model');
        $this->load->model('purchases_model');
        $this->load->model('category_model');
        $this->load->model('warehouse_model');
        $this->load->model('damages_model');
    }
    function index()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'list_damages';
        $data['title']          = $this->title;
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $this->load->view('damages/damages-list', $data);
    }
    function add()
    {
        $data['main_menu_name'] = $this->main_menu_name;
        $data['sub_menu_name']  = 'add_damages';
        $data['title']          = 'Add '.$this->title;
        $data['warehouse'] = $this->warehouse_model->get_warehouses();
        $this->load->view('damages/damages-add', $data);
    }
    function save_damage()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('warehouse_id', 'Warehouse', 'required');
        $this->form_validation->set_rules('date_time', 'Time Stamp', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'status' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            $products            = $this->input->post('row');
            if (!count($products) > 0) {
                $st = array(
                    'status' => false,
                    'validation' => "No products received!"
                );
                echo json_encode($st);
                exit;
            }
            $warehouse_id        = $this->input->post('warehouse_id');
            $trnsfr_total = 0;
            $item_batch = array();
            foreach ($products as $row) {
                $sub_total =  $row['quantity'] * $row['product_cost'];
                $item_data        = array(
                    'product_id' => $row['product_id'],
                    'quantity' => $row['quantity'],
                    'unit_cost' => $row['product_cost'],
                    'sub_total' => $sub_total,
                    'warehouse_id' => $warehouse_id
                );
                $trnsfr_total += $sub_total;
                $item_batch[] = $item_data;
            }

            $reference_no           = $this->common_model->gen_ref_number('damage_id', 'product_damage', 'DMG');
            $warehouse_damage_id  = $this->common_model->get_next_value('warehouse_damage_id', 'product_damage', $warehouse_id);
            
            $date_time     = $this->input->post('date_time');
            $note                = $this->input->post('note');
            $user_id             = $this->session->userdata('ss_user_id');
            $uuid                = $this->input->post('uuid');

            $pur_data        = array(
                'warehouse_id' => $warehouse_id,
                'warehouse_damage_id' => $warehouse_damage_id,
                'reference_no' => $reference_no,
                'date_time' => $date_time,
                'total' => $trnsfr_total,
                'note' => $note,
                'user_id' => $user_id,
                'uuid' => $uuid,
            );
            $last_id             = $this->common_model->save($pur_data, 'product_damage');
            if ($last_id) {
                foreach ($item_batch as $key => $row) {
                    $item_batch[$key]['damage_id'] = $last_id;
                }
                $item_lst_id             = $this->common_model->save_batch($item_batch, 'product_damage_item');
                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'validation' => 'Done!',
                        'value' => array(
                            'last_id' => $last_id
                        )
                    );
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'validation' => 'Error occurred. please contact your system administrator-1.'
                    );
                    echo json_encode($st);
                }
            } else {
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator-2.'
                );
                echo json_encode($st);
            }
        }
    }
    function get_list(){
        $start         = $this->input->get('start');
        $length        = $this->input->get('length');
        $search_key    = $this->input->get('search');
        $filter = array(
            "search_key"=>$search_key['value'],
            "warehouse_id"=>($this->input->get('warehouse_id'))?$this->input->get('warehouse_id'):$this->session->userdata('ss_warehouse_id')
        );
        $values        = $this->damages_model->get_damages($start, $length, $filter);
        $value_count   = $this->damages_model->get_damages('', '', '');
        $totalData     = $value_count;
        $totalFiltered = $totalData;
        $data          = array();
        if (!empty($values)) {
            foreach ($values as $row) {
                $nestedData     = array();
                $nestedData[]   = $row->date_time;
                $nestedData[]   = $row->reference_no;
                $nestedData[]   = $row->warehouse_id ;
                $nestedData[]   = $row->total;
                $nestedData[]   = $row->note;
                $nestedData[]   = '';
                $data[] = $nestedData;
            }
        }
        $output = array(
            'data' => $data,
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered)
        );
        echo json_encode($output);
    }
}
