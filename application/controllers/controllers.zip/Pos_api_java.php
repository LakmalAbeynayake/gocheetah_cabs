<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class pos_api_java extends CI_Controller
{
    var $main_menu_name = "";
    var $sub_menu_name = "";
    public function __construct()
    {
        parent::__construct();
        $this->load->model('common_model');
        $this->load->model('warehouse_model');
        $this->load->model('api_model');
        //$this->load->model('customer_model');

        header('Content-Type: application/json');
        if (!isset($_SERVER['CONTENT_TYPE'])) {
            $data = array(
                "status" => 0,
                "msg" => "Content Type undefined.",
                "err_code" => "mrepus400-i"
            );
            echo json_encode($data);
            exit();
        }
        if ($_SERVER['CONTENT_TYPE'] !== "application/json" && $_SERVER['CONTENT_TYPE'] !== "application/json; charset=utf-8") {
            $data = array(
                "status" => 0,
                "msg" => "Invalid content type! JSON required. Received:" . $_SERVER['CONTENT_TYPE'],
                "err_code" => "mrepus401-i"
            );
            echo json_encode($data);
            exit();
        }
        $_POST = json_decode(file_get_contents("php://input"), true);
        if ($this->router->method != "login") {
            if (!is_logged_in()) {
                $st = array(
                    "status" => 0,
                    "msg" => "session expired!",
                    "err_code" => "mrepus201-a"
                );
                echo json_encode($st);
                exit;
            }
        }
    }
    public function index()
    {
        $data = array(
            "status" => 0,
            "msg" => "Error",
            "err_code" => "mrepus200-a"
        );
        echo json_encode($data);
    }
    function login()
    {
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                "status" => 0,
                "msg" => validation_errors()
            );
            echo json_encode($st);
        } else {
            $user_username = $this->input->post('username');
            $password      = $this->input->post('password');
            $user_id       = $this->user_model->login($user_username, $password);
            if ($user_id) {
                $data['user_details'] = $this->user_model->get_user_info($user_id);
                $ss_user_username     = $data['user_details']['user_username'];
                $ss_user_id           = $data['user_details']['user_id'];
                $ss_group_id          = $data['user_details']['group_id'];
                $ss_warehouse_id      = $data['user_details']['warehouse_id'];
                $ss_user_first_name   = $data['user_details']['user_first_name'];
                $ss_user_last_name    = $data['user_details']['user_last_name'];
                $ss_user_group_name   = $data['user_details']['user_group_name'];
                $sesdata              = array(
                    'ss_user_username' => $ss_user_username,
                    'ss_user_id' => $ss_user_id,
                    'ss_group_id' => $ss_group_id,
                    'ss_warehouse_id' => $ss_warehouse_id,
                    'ss_user_first_name' => $ss_user_first_name,
                    'ss_user_last_name' => $ss_user_last_name,
                    'ss_user_group_name' => $ss_user_group_name
                );
                $this->user_model->create_user_sessions($sesdata);
                $st = array(
                    "success" => true,
                    "msg" => "Done!",
                    "session" => $this->session->userdata
                );
                $this->api_model->add_session();
                echo json_encode($st);
            } else {
                $st = array(
                    "success" => false,
                    "msg" => "Invalid username or password!",
                    "err_code" => "mrepus202-a"
                );
                echo json_encode($st);
            }
        }
    }
    function logout()
    {
        $sesdata = array(
            'ss_user_username' => '',
            'ss_user_id' => '',
            'ss_group_id' => '',
            'ss_warehouse_id' => '',
            'ss_user_first_name' => '',
            'ss_user_last_name' => '',
            'ss_user_group_name' => ''
        );
        $this->common_model->add_user_activitie("Logout User");
        $this->session->unset_userdata($sesdata);
        $st = array(
            'status' => 1,
            'msg' => "Logged out successfully!"
        );
        echo json_encode($st);
    }
    function check_permission()
    {
        $fn_id      = $this->input->post('fn_id');
        if ($this->common_model->check_permission($fn_id, $this->session->userdata('ss_group_id'), 1)) {
            $st = array(
                'success' => true
            );
            echo json_encode($st);
        } else {
            $st = array(
                'success' => false
            );
            echo json_encode($st);
        }
    }
    function suggestions()
    {
        $term = $this->input->post('term');
        $data = $this->api_model->get_products_suggestions($term);

        if (!empty($data)) {
            foreach ($data as $key => $row) {
                $data[$key]->product_id    = $data[$key]->product_id + 0;
                $data[$key]->product_price = $data[$key]->product_price + 0;
            }
            echo json_encode(array(
                "success" => true,
                "msg" => "Success",
                "suggetions" => $data
            ));
        } else {
            $jproduct = array();
            echo json_encode(array(
                "status" => 0,
                "msg" => "Failed. (Error code: mrepus403-i)",
                "suggetions" => $jproduct
            ));
        }
    }
    function get_products($category_id = "")
    {
        $category_id = $this->input->post('category_id');
        $d           = $this->api_model->get_product_by_cat_id($category_id);
        if (!empty($d)) {
            foreach ($d as $key => $row) {
                $d[$key]->product_id    = $d[$key]->product_id + 0;
                $d[$key]->product_price = $d[$key]->product_price + 0;
                $d[$key]->cat_id        = $d[$key]->cat_id + 0;
                $d[$key]->sub_cat_id    = $d[$key]->sub_cat_id + 0;
                $d[$key]->min_order_qty = $d[$key]->min_order_qty + 0;
            }
            echo json_encode(array(
                "status" => 1,
                "msg" => "Success",
                "products_of_cat" => $d
            ));
        } else {
            $jproduct = array();
            echo json_encode(array(
                "status" => 0,
                "msg" => "Failed. (Error code: mrepus403-i)",
                "products_of_cat" => $jproduct
            ));
        }
    }
    function get_product_info()
    {
        $product_id = $this->input->post('product_id');
        $product_code = $this->input->post('product_code');
        $data          = $this->api_model->get_product_by_product_id($product_id, $product_code);
        if (!empty($data)) {
            foreach ($data as $key => $row) {
                $data[$key]->product_id    = $data[$key]->product_id + 0;
                $data[$key]->product_price = $data[$key]->product_price + 0;
            }
            echo json_encode(array(
                "success" => true,
                "msg" => "Success",
                "info" => $data
            ));
        } else {
            $jproduct = array();
            echo json_encode(array(
                "status" => 0,
                "msg" => "Failed. (Error code: mrepus403-i)",
                "info" => $jproduct
            ));
        }
    }
    function save_customer()
    {
        $msg          = "";
        $status       = 0;
        $returndata   = "";
        $cus_name     = $this->input->post('cus_name');
        $cus_phone    = $this->input->post('cus_phone');
        $cus_email    = $this->input->post('cus_email');
        $home_address = $this->input->post('home_address');
        $type         = $this->input->post('type');
        $cus_id       = intval($this->input->post('cus_id'));
        $this->load->library('form_validation');
        if ($type == 'A') {
            /* $_POST['cus_phone'] = $this->format_phone($this->input->post('cus_phone')); */
            $this->form_validation->set_rules('cus_name', 'Name', 'required');
            $this->form_validation->set_rules('cus_phone', 'Phone', 'required|is_unique[customer.cus_phone]');
            $this->form_validation->set_rules('cus_email', 'Email', 'required');
            $this->form_validation->set_rules('home_address', 'Home Address', 'required');
        } else if ($type == 'E') {
            $this->form_validation->set_rules('cus_name', 'Name', 'required');
            $this->form_validation->set_rules('cus_email', 'Email', 'required');
            $this->form_validation->set_rules('home_address', 'Home Address', 'required');
        }
        if (!filter_var($cus_email, FILTER_VALIDATE_EMAIL)) {
            $status = 0;
            $msg    = "Invalid email format. (Error code: mrepus300-v)";
        } else if ($this->form_validation->run() == FALSE) {
            $status = 0;
            $msg    = validation_errors();
        } else {
            $cusdata = "";
            if ($type == 'A') {
                $cus_code = $this->Common_Model->gen_ref_number('cus_id', 'customer', 'CUS/');
                $cusdata  = array(
                    'cus_name' => $cus_name,
                    'cus_code' => $cus_code,
                    'cus_email' => $cus_email,
                    'cus_address' => $home_address,
                    'cus_phone' => $cus_phone,
                    'country_id' => "251"
                );
            }
            if ($type == 'E') {
                $cusdata = array(
                    'cus_name' => $cus_name,
                    'cus_email' => $cus_email,
                    'cus_address' => $home_address
                );
            }
            $result = $this->Customer_Model->save_customer($cusdata, $cus_id);
            if ($type == 'A') {
                $lastid = $this->db->insert_id();
                if ($lastid) {
                    $returndata = array(
                        'cus_id' => $lastid,
                        'type' => $type,
                        'cus_email' => $cus_email,
                        'cus_status' => 1,
                        'cus_name' => $cus_name,
                        'cus_address' => $home_address,
                        'cus_phone' => $cus_phone
                    );
                } else {
                    $returndata = array();
                    $status     = 0;
                    $msg        = "Failed! (Error code: mrepus402-i)";
                }
            } else if ($type == 'E') {
                $returndata = array(
                    'cus_id' => $cus_id,
                    'type' => $type,
                    'cus_email' => $cus_email,
                    'cus_status' => 1,
                    'cus_name' => $cus_name,
                    'cus_address' => $home_address,
                    'cus_phone' => $cus_phone
                );
                $status     = 1;
                $msg        = "Updated successfully!";
            }
        }
        echo json_encode(array(
            "status" => $status,
            "msg" => $msg,
            "cus_data" => $returndata
        ));
    }
    function is_api_logged_in($session_id)
    {
        $logged_in = false;
        $ss_data   = $this->api_model->get_session($session_id);
        if ($ss_data) {
            $logged_in = true;
        }
        return $logged_in;
    }
    function get_userdata()
    {
        echo json_encode(array(
            "status" => 1,
            "msg" => "Success",
            "userdata" => $this->session->userdata()
        ));
    }
    function save_sale()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('sale_uuid', 'UUID', 'required|is_unique[sales.sale_uuid]');
        $this->form_validation->set_rules('sale_date_time', 'Date Time', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            $st = array(
                'status' => false,
                'validation' => validation_errors()
            );
            echo json_encode($st);
        } else {
            /* sale items */
            $products            = $this->input->post('sl_products');
            if (!count($products) > 0) {
                $st = array(
                    'status' => false,
                    'validation' => "No products received!"
                );
                echo json_encode($st);
                exit;
            }
            $warehouse_id        = $this->session->userdata('ss_warehouse_id');
            $cost_total = 0;
            $sale_total = 0;
            $total_discount = 0;
            $item_batch = array();
            foreach ($products as $row) {
                $product_details = $this->api_model->get_product_by_product_id($row['product_id']);
                
                $sub_total =  $row['quantity'] * $product_details[0]->product_price;
                $sub_cost_total =  $row['quantity'] * $product_details[0]->product_cost;
                $item_data = array(
                    'product_id' => $row['product_id'],
                    'quantity' => $row['quantity'],
                    'single_unit_price_wd' => $product_details[0]->product_price,
                    'single_unit_cost' => $product_details[0]->product_cost,
                    'single_unit_discount' => 0,
                    'total_item_cost' => $sub_cost_total,
                    'total_item_price' => $sub_total,
                    'total_discount_amount' => $total_discount,
                    'sub_total' => $sub_total,
                    'warehouse_id' => $warehouse_id
                );
                $cost_total += $sub_cost_total;
                $sale_total += $sub_total;
                $item_batch[] = $item_data;
            }
            /* end sale items */
            /* start sale */
            $reference_no        = $this->common_model->gen_ref_number('warehouse_sale_id', 'sales', 'SL');
            $warehouse_info      = $this->warehouse_model->get_warehouse_info($warehouse_id);
            $warehouse_sale_id   = $this->common_model->get_next_value('warehouse_sale_id', 'sales', $warehouse_id);
            $sale_customer_id    = $this->input->post('sale_customer_id');
            $sale_date_time      = $this->input->post('sale_date_time');
            $sale_note           = $this->input->post('sale_note');
            $user_id             = $this->session->userdata('ss_user_id');
            $sale_uuid           = $this->input->post('sale_uuid');
            
            $sales_data = array(
                'warehouse_id' => $warehouse_id,
                'warehouse_sale_id' => $warehouse_sale_id,
                'sale_uuid' => $sale_uuid,
                'sale_reference_no  ' => $warehouse_info->code."".$reference_no,
                'sale_customer_id  ' => $sale_customer_id,
                'sale_date_time' => $sale_date_time,
                'sale_cost' => $cost_total,
                'sale_note' => $sale_note,
                'sale_total' => $sale_total,
                'sale_user_id' =>  $user_id
            );
            /* end sale */
            /* save sale */
            /* start payments */
            $payments            = $this->input->post('sl_payments');
            if (!count($payments) > 0) {
                $st = array(
                    'status' => false,
                    'validation' => "No payments received!"
                );
                echo json_encode($st);
                exit;
            }
            $total_paid = 0;
            $payment_batch = array();
            foreach ($payments as $row) {
                $payment_data = array(
                    'pymnt_type' => 'sale',
                    'pay_by' => $row['pay_by'],
                    'pymnt_date_time' => $sale_date_time,
                    'payment_date_for' => $sale_date_time,
                    'pymnt_amount' => $row['given_amount'],
                    'warehouse_id' => $warehouse_id,
                    'user_id' => $this->session->userdata('ss_user_id')
                );
                $total_paid += $row['given_amount'];
                $payment_batch[] = $payment_data;
            }
            /* end payments */
            $sales_data['sale_given_amount'] = $total_paid;
            $sales_data['sale_balance'] = $total_paid-$sale_total;
            $last_id             = $this->common_model->save($sales_data, 'sales');
            if ($last_id) {
                /* add sale_id to sale_items */
                foreach ($item_batch as $key => $row) {
                    $item_batch[$key]['sale_id'] = $last_id;
                }
                /* save sale items */
                $item_lst_id             = $this->common_model->save_batch($item_batch, 'sale_items');
                if (!$item_lst_id) {
                    $st = array(
                        'success' => false,
                        'validation' => 'Error!'
                    );
                    echo json_encode($st);
                    exit;
                }
                /* end sale items */
                /* add reference_id (sale_id) to sale_items */
                foreach ($payment_batch as $key => $row) {
                    $payment_batch[$key]['reference_id'] = $last_id;
                }
                /* end sale payments */
                $item_lst_id             = $this->common_model->save_batch($payment_batch, 'payments');

                if ($item_lst_id) {
                    $st = array(
                        'success' => true,
                        'validation' => 'Done!',
                        'values' => array(
                            'last_id' => $last_id
                        )
                    );
                    echo json_encode($st);
                } else {
                    $st = array(
                        'success' => false,
                        'validation' => 'Error occurred. please contact your system administrator.'
                    );
                    echo json_encode($st);
                }
            } else {
                $st = array(
                    'success' => false,
                    'validation' => 'Error occurred. please contact your system administrator.'
                );
                echo json_encode($st);
            }
        }
    }
}
